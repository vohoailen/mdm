STEP 1) Download Openssl and add the folder to system path.
Make sure that openSSL can be executed from any directory

STEP 2) Update server.cnf with your IP address or hostname.  Replace <SERVER_IP> with this information.

Step 3)
Run make_certs.bat

You will be guided with 8 different steps.

After this you could follow the other guidelines give. There is no more OS dependancy.


#!/bin/bash

cd ../vendor-signing/com/softhinker
javac -cp "../../lib/dom4j-1.6.1.jar:./" Test.java 
cd ../../
java -cp "./lib/dom4j-1.6.1.jar:./" com.softhinker.Test
